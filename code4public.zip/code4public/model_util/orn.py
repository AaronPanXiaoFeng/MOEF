import tensorflow as tf
from rnn import create_rnn_encoder

def orn(occasion_signal_feat_list, occasion_signal_feat_dict, reuse):

    ## fft representation
    occasion_signal_fft_rep_list = []
    for signal_feat in occasion_signal_feat_list:
        occasion_signal_feat = occasion_signal_feat_dict[signal_feat]
        time_domian_seq = tf.complex(occasion_signal_feat, tf.zeros(tf.shape(occasion_signal_feat)), name=signal_feat + "_complex")
        freq_domian_seq = tf.spectral.fft(time_domian_seq)
        freq_signal_real = tf.real(freq_domian_seq)
        freq_signal_imag = tf.imag(freq_domian_seq)
        amplitude = tf.sqrt(tf.square(freq_signal_real) + tf.square(freq_signal_imag))
        phase = tf.atan(freq_signal_real / (freq_signal_imag + 1e-8))
        occasion_signal_fft = tf.concat([amplitude, phase], axis=-1, name=signal_feat + "freq_feature")
        occasion_signal_fft_rep_list.append(occasion_signal_fft)
    occasion_signals_fft_rep = tf.concat(occasion_signal_fft_rep_list, axis=-1)

    ## Long Short Term Memory
    last_output = create_rnn_encoder(occasion_signals_fft_rep, reuse)

    return last_output