import tensorflow as tf
from tensorflow.contrib import layers

def create_rnn_encoder(inputs, reuse):
    with tf.variable_scope("encoder", reuse=reuse):
        cell = create_rnn_cell(unit_type='lstm',
                                num_units=inputs.get_shape().as_list()[2],
                                num_layers=1,
                                num_residual_layers=1,
                                forget_bias=1.0,
                                attention_window_size=None)

        rnn_outputs, last_states = tf.nn.dynamic_rnn(cell=cell,
                                                     dtype=tf.float32,
                                                     inputs=inputs)

        rnn_outputs = layers.layer_norm(rnn_outputs)

    return rnn_outputs[:,-1,:]


def create_rnn_cell(unit_type, num_units, num_layers, num_residual_layers,
                    forget_bias, attention_window_size, single_cell_fn=None):
    """Create multi-layer RNN cell.

      Args:
        unit_type: string representing the unit type, i.e. "lstm".
        num_units: the depth of each unit.
        num_layers: number of cells.
        num_residual_layers: Number of residual layers from top to bottom. For
          example, if `num_layers=4` and `num_residual_layers=2`, the last 2 RNN
          cells in the returned list will be wrapped with `ResidualWrapper`.
        forget_bias: the initial forget bias of the RNNCell(s).
          the probability of dropout.  this is ignored if `train_mode is True`.
        single_cell_fn: single_cell_fn: allow for adding customized cell.
          When not specified, we default to model_helper._single_cell
      Returns:
        An `RNNCell` instance.
    """
    cell_list = _cell_list(unit_type=unit_type,
                           num_units=num_units,
                           num_layers=num_layers,
                           num_residual_layers=num_residual_layers,
                           forget_bias=forget_bias,
                           single_cell_fn=single_cell_fn)

    if len(cell_list) == 1:  # Single layer.
        final_cell = cell_list[0]
    else:                    # Multi layers
        final_cell = tf.contrib.rnn.MultiRNNCell(cell_list)

    #  Attention Wrapper Cell
    if attention_window_size is not None:
        final_cell = tf.contrib.rnn.AttentionCellWrapper(final_cell, attention_window_size)
    return final_cell

def _cell_list(unit_type, num_units, num_layers, num_residual_layers,
               forget_bias, single_cell_fn=None):
    """Create a list of RNN cells."""
    if not single_cell_fn:
        single_cell_fn = _single_cell

    cell_list = []
    for i in range(num_layers):
        single_cell = single_cell_fn(
            unit_type=unit_type,
            num_units=num_units,
            forget_bias=forget_bias,
            residual_connection=(i >= num_layers - num_residual_layers)
        )
        cell_list.append(single_cell)

    return cell_list


def _single_cell(unit_type, num_units, forget_bias, residual_connection=False):
    """Create an instance of a single RNN cell."""
    # dropout (= 1 - keep_prob) is set to 0 during eval and infer
    # Cell Type
    if unit_type == "lstm":
        single_cell = tf.contrib.rnn.BasicLSTMCell(num_units, forget_bias=forget_bias)
    elif unit_type == "lstmblock":
        single_cell = tf.contrib.rnn.LSTMBlockCell(num_units, forget_bias=forget_bias)
    elif unit_type == "lstmfused":
        single_cell = tf.contrib.rnn.LSTMBlockFusedCell(num_units, forget_bias=forget_bias)
    elif unit_type == "gru":
        single_cell = tf.contrib.rnn.GRUCell(num_units)
    elif unit_type == "layer_norm_lstm":
        single_cell = tf.contrib.rnn.LayerNormBasicLSTMCell(num_units, forget_bias=forget_bias, layer_norm=True)
    else:
        raise ValueError("Unknown unit type %s!" % unit_type)

    # Residual
    if residual_connection:
        single_cell = tf.contrib.rnn.ResidualWrapper(single_cell)

    return single_cell